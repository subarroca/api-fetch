import { RequestClient } from './request-client';


new RequestClient('./response');
